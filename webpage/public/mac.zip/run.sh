file=love.jpg
mkdir $HOME/pvt
cp ./$file $HOME/pvt/
osascript -e 'tell application "System Events" to tell every desktop to set picture to "'$HOME'/pvt/'$file'"'